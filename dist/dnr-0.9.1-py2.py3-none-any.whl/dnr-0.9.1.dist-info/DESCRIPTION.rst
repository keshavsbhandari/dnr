
RNN based word2vec implementation for news recommendation

Use Recommendation module to make your own content based news recommendation
using the fact that reader can news next news provided that they had read certain news

More information at: https://github.com/keshavsbhandari/dnr


